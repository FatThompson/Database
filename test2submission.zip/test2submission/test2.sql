source companyDB.sql;
\T test2-session.txt
source test2_querya.sql;
source test2_queryb.sql;
source test2_queryc.sql;
source test2_queryd.sql;
source test2_querye.sql;
\t