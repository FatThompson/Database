/* Retrieve social security numbers of employees that work on projects. */

Select distinct essn
#distinct removes duplicate values.
from works_on
#where true;