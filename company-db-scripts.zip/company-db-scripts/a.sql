SOURCE Assg_Oct17_query1.sql;
SOURCE Assg_Oct17_query2.sql;
SOURCE Assg_Oct17_query3.sql;
SOURCE Assg_Oct17_query4.sql;
SOURCE Assg_Oct17_query5.sql;