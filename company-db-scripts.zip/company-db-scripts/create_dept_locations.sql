create table dept_locations(
    Dnumber Integer,
    Dlocation Varchar(15),
    Primary key(Dnumber,Dlocation)
);