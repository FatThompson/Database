UPDATE employees 
    SET super_ssn = 888665555
    WHERE super_ssn = 88665555;

UPDATE departments 
    SET mgr_ssn = 888665555
    WHERE mgr_ssn = 88866555;