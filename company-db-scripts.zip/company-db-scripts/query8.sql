SELECT Ssn, Dno, Dname
FROM employees, departments
WHERE Dno=Dnumber;