UPDATE projects
SET Plocation='Bellaire', Dnum=5
WHERE pnumber=10;

UPDATE projects
SET Plocation='Stafford', Dnum=4
WHERE pnumber=10;