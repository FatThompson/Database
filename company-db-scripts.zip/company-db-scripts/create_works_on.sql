create table works_on(
    Essn Integer,
    Pno Integer,
    Hours Decimal(3,1),
    Primary key(Essn, Pno)
);