SELECT * 
FROM departments, dependents, 
     dept_locations, employees,
     projects, works_on;