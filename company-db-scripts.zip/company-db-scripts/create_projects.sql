create table projects(
    Pname Varchar(25),
    Pnumber Integer,
    Plocation Varchar(25),
    Dnum Integer,
    Primary key(Pnumber)
);