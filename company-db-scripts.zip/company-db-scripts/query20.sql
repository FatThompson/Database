DELETE FROM projects 
WHERE dnum=5;