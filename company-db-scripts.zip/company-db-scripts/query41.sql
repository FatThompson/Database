DELETE FROM employees
WHERE ssn=333445555;
select * from employees;