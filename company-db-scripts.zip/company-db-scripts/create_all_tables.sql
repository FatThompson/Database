source create_departments.sql;
source create_dependents.sql;
source create_dept_locations.sql;
source create_employees.sql;
source create_projects.sql;
source create_works_on.sql;