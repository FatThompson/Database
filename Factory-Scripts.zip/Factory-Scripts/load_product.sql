LOAD DATA LOCAL INFILE "product.dat" INTO 
    TABLE product 
    FIELDS ENCLOSED BY "\'" 
    TERMINATED BY ","
;